// 1.点击查看详情时后，跳转到课程详情页，并提供当前商品的编号
document.querySelectorAll('[data-jump-to-detail]').forEach(function(e,i){
	e.onclick=function(){
		//提前准备跳转地址
		let cid=e.dataset.jumpToDetail
		let url='course-detail.html?courseId='+cid
		//跳转到课程详情页
		open(url)
		//window.open('course-detail.html','_self')//当前页打开新页面
		//window.open('course-detail.html','_blank')//在空白页打开新页面
		//window.open('course-detail.html')//在空白页打开新页面
	}
})